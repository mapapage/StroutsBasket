package //<editor-fold defaultstate="collapsed" desc="comment">
com.myapp.struts
//</editor-fold>
;



public class basic {
    
     public static void main(String argv[]) {
  
        calcQuantity cafe = new calcQuantity();
        cafe.setqcafe("qcafe");
        
        calcQuantity sugar = new calcQuantity();
        sugar.setqsugar("qsugar");
        
        calcQuantity water = new calcQuantity();
        water.setqwater("qwater");
      
}
}







